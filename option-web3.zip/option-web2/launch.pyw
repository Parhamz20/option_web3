"""Local Windows launcher. Runs with pythonw: no terminal required."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import tkinter as tk
from tkinter import messagebox
from urllib.request import urlopen
import webbrowser

ROOT = Path(__file__).resolve().parent
URL = "http://127.0.0.1:8000"


def server_ready():
    try:
        with urlopen(URL + "/openapi.json", timeout=0.4) as response:
            return json.load(response).get("info", {}).get("title") == "Option Analyzer API"
    except Exception:
        return False


class Launcher:
    def __init__(self, window):
        self.window = window
        self.process = None
        self.log = None
        self.existing = False
        window.title("Option Analyzer")
        window.geometry("440x240")
        window.resizable(False, False)
        window.configure(bg="#f5f7fb")
        tk.Label(window, text="آپشن آنالایزر", font=("Tahoma", 19, "bold"), bg="#f5f7fb", fg="#17263d").pack(pady=(22, 10))
        self.status = tk.StringVar(value="در حال راه‌اندازی سرور…")
        tk.Label(window, textvariable=self.status, font=("Tahoma", 10), bg="#f5f7fb", wraplength=410).pack(pady=8)
        self.open_button = tk.Button(window, text="باز کردن سایت", command=lambda: webbrowser.open(URL), state="disabled", font=("Tahoma", 11), bg="#1a73e8", fg="white", relief="flat", padx=20, pady=7)
        self.open_button.pack(pady=8)
        self.stop_button = tk.Button(window, text="توقف سرور و خروج", command=self.close, font=("Tahoma", 10), relief="flat", bg="#f5f7fb")
        self.stop_button.pack()
        window.protocol("WM_DELETE_WINDOW", self.close)
        window.after(100, self.start)

    def start(self):
        if server_ready():
            self.existing = True
            self.stop_button.config(text="بستن این پنجره")
            self.ready()
            return
        try:
            with socket.socket() as probe:
                probe.bind(("127.0.0.1", 8000))
            self.log = (ROOT / "launcher.log").open("w", encoding="utf-8")
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            server_python = Path(sys.executable).with_name("python.exe")
            if not server_python.exists():
                server_python = Path(sys.executable)
            self.process = subprocess.Popen(
                [str(server_python), "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000", "--reload", "--reload-dir", str(ROOT / "app")],
                cwd=ROOT, stdout=self.log, stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NO_WINDOW, env=env,
            )
            self.deadline = time.monotonic() + 45
            self.window.after(300, self.poll)
        except Exception as error:
            self.fail(str(error))

    def poll(self):
        if self.process.poll() is not None:
            self.fail("سرور اجرا نشد. جزئیات در فایل launcher.log ذخیره شده است.")
        elif server_ready():
            self.ready()
        elif time.monotonic() > self.deadline:
            self.fail("راه‌اندازی طول کشید. فایل launcher.log را بررسی کنید.")
        else:
            self.window.after(500, self.poll)

    def ready(self):
        self.status.set("سایت آماده است؛ این پنجره را هنگام کار باز نگه دارید." if not self.existing else "سرور از قبل روشن است؛ سایت باز شد.")
        self.open_button.config(state="normal")
        webbrowser.open(URL)

    def fail(self, detail):
        self.status.set("راه‌اندازی ناموفق بود.")
        messagebox.showerror("Option Analyzer", detail, parent=self.window)

    def close(self):
        if self.process and self.process.poll() is None:
            subprocess.run(["taskkill", "/PID", str(self.process.pid), "/T", "/F"], creationflags=subprocess.CREATE_NO_WINDOW, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if self.log:
            self.log.close()
        self.window.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    Launcher(root)
    root.mainloop()
