Option Explicit
Dim shell, files, base, python, candidate, folder, entry, pathEntry
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
base = files.GetParentFolderName(WScript.ScriptFullName)
python = ""
candidate = base & "\.venv\Scripts\pythonw.exe"
If files.FileExists(candidate) Then python = candidate
folder = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Programs\Python"
If python = "" And files.FolderExists(folder) Then
  For Each entry In files.GetFolder(folder).SubFolders
    candidate = entry.Path & "\pythonw.exe"
    If files.FileExists(candidate) Then python = candidate
  Next
End If
If python = "" Then
  For Each pathEntry In Split(shell.ExpandEnvironmentStrings("%PATH%"), ";")
    If pathEntry <> "" And InStr(LCase(pathEntry), "windowsapps") = 0 Then
      candidate = files.BuildPath(Replace(pathEntry, """", ""), "pythonw.exe")
      If files.FileExists(candidate) Then python = candidate
    End If
  Next
End If
If python = "" Then
  MsgBox "Python was not found. Install Python with Tkinter and the project requirements first.", 16, "Option Analyzer"
  WScript.Quit 1
End If
shell.CurrentDirectory = base
shell.Run """" & python & """ """ & base & "\launch.pyw" & """", 0, False
